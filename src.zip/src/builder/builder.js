import { builder } from "@builder.io/react";

builder.init(import.meta.env.VITE_BUILDER_PUBLIC_KEY);
